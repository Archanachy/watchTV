import background from './background.png';
import watchtv_icon from './watchtv_icon.png';
import watchtv from './watchtv.webp';
import errorIcon from './errorIcon.jpg'
import Profile from './profile.jpg';
import RedOne from './red-one.jpg';
import Movies from './Movies_Icon.png';
import eyeIcon from './eyeIcon.png';
import eyeSlashIcon from './eyeSlashIcon.png';




export {background, watchtv_icon,watchtv, errorIcon,Profile,RedOne, Movies,eyeIcon,  eyeSlashIcon};